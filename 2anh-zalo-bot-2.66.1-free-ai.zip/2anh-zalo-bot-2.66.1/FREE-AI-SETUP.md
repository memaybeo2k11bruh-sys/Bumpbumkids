# Cấu hình AI nhiều nhà cung cấp (tuỳ chọn)

Cấu hình này dùng Hermes Agent fallback, không sửa luồng Zalo hay dữ liệu memory:

1. Thêm `GEMINI_API_KEY`, `GROQ_API_KEY`, `OPENROUTER_API_KEY` vào Railway Variables.
2. Đảm bảo Hermes đã được cài và `HERMES_HOME` trỏ đúng thư mục Hermes (mặc định `~/.hermes`).
3. Chạy trong Railway shell: `npm run configure:free-ai`.
4. Khởi động lại Hermes Gateway.

Thứ tự: Gemini (chính) → Groq → OpenRouter (dự phòng). Mỗi provider chỉ hoạt động khi key hợp lệ và model còn được cung cấp. Có thể đổi model qua `GEMINI_MODEL`, `GROQ_MODEL`, `OPENROUTER_FREE_MODEL` trước khi chạy script.

Script tạo bản sao `config.yaml` trước khi ghi. Nó chỉ thay cấu hình model chính và fallback chain; các phần cấu hình khác được giữ lại. Chạy lại script sẽ cập nhật chuỗi theo các biến hiện tại.

Lưu ý: quota miễn phí thay đổi theo nhà cung cấp/model; đây không phải dịch vụ không giới hạn. Không đưa API key vào mã nguồn, ZIP công khai hoặc tin nhắn Zalo.
