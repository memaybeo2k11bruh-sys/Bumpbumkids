#!/usr/bin/env node
/** Configure Hermes primary Gemini with Groq and OpenRouter fallbacks. */
import { existsSync, readFileSync, writeFileSync, copyFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, resolve } from 'node:path';
import { parseDocument, isMap, isSeq } from 'yaml';

const home = resolve(process.env.HERMES_HOME || join(homedir(), '.hermes'));
const configPath = join(home, 'config.yaml');
if (!existsSync(configPath)) {
  console.error(`Không tìm thấy ${configPath}. Hãy chạy cài đặt Hermes trước.`);
  process.exit(1);
}
if (!process.env.GEMINI_API_KEY && !process.env.GOOGLE_API_KEY) {
  console.error('Thiếu GEMINI_API_KEY (hoặc GOOGLE_API_KEY) trong biến môi trường Railway.');
  process.exit(1);
}
if (!process.env.GROQ_API_KEY || !process.env.OPENROUTER_API_KEY) {
  console.error('Cần đặt cả GROQ_API_KEY và OPENROUTER_API_KEY trong Railway Variables.');
  process.exit(1);
}

const source = readFileSync(configPath, 'utf8');
const doc = parseDocument(source, { intAsBigInt: true });
if (doc.errors.length) throw doc.errors[0];
if (doc.contents == null) doc.contents = doc.createNode({});
if (!isMap(doc.contents)) throw new Error('config.yaml phải là YAML mapping.');
const ensureMap = (path) => {
  for (let i = 1; i <= path.length; i++) {
    const part = path.slice(0, i);
    if (!isMap(doc.getIn(part, true))) doc.setIn(part, doc.createNode({}));
  }
};
const set = (path, value) => { ensureMap(path.slice(0, -1)); doc.setIn(path, value); };
const del = (path) => { if (doc.hasIn(path)) doc.deleteIn(path); };

// Explicit opt-in command: switch the primary chat provider to native Gemini.
set(['model', 'provider'], 'gemini');
set(['model', 'default'], process.env.GEMINI_MODEL || 'gemini-2.5-flash');
// Remove endpoint credentials belonging to a previous custom gateway; provider keys remain in Railway env.
for (const key of ['base_url', 'api_key', 'key_env']) del(['model', key]);

set(['providers', 'groq', 'api'], 'https://api.groq.com/openai/v1');
set(['providers', 'groq', 'key_env'], 'GROQ_API_KEY');
const fallbacks = [
  { provider: 'custom:groq', model: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile' },
  { provider: 'openrouter', model: process.env.OPENROUTER_FREE_MODEL || 'meta-llama/llama-3.3-70b-instruct:free' },
];
set(['fallback_providers'], fallbacks);

const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*$/, '');
const backup = `${configPath}.bak-free-ai-${stamp}`;
copyFileSync(configPath, backup);
writeFileSync(configPath, doc.toString({ lineWidth: 0 }), 'utf8');
console.log('Đã cấu hình Gemini chính → Groq → OpenRouter.');
console.log(`Bản sao cấu hình cũ: ${backup}`);
console.log('Khởi động lại Hermes Gateway để áp dụng.');
