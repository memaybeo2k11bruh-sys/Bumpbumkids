import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { INSTALL_TIMEOUT_MS, runSelfUpdate } from './self-update-lib.js';

function setup(t, { git = true, healthy = () => ({ ok: true }), runHook = () => '', lockChangesOn = '' } = {}) {
  // lockChangesOn: lệnh nào chạy xong thì đổi THƯ VIỆN trong package-lock (không chỉ số phiên bản).
  const root = mkdtempSync(join(tmpdir(), 'zalo-selfupdate-'));
  t.after(() => rmSync(root, { recursive: true, force: true }));
  if (git) mkdirSync(join(root, '.git'));
  writeFileSync(join(root, 'package-lock.json'), 'v1');
  const tmp = join(root, 'tmp'); mkdirSync(tmp);
  const calls = []; const logs = [];
  let clock = 0;
  const deps = {
    log: (s) => logs.push(s),
    run: async (cmd, args) => {
      const line = `${cmd.endsWith('node') || cmd.endsWith('node.exe') ? 'node' : cmd} ${args.join(' ')}`;
      calls.push(line);
      if (lockChangesOn && line.includes(lockChangesOn)) writeFileSync(join(root, 'package-lock.json'), JSON.stringify({ packages: { 'node_modules/x': { version: String(calls.length) } } }));
      const r = runHook(line);
      if (r instanceof Error) throw r;
      if (cmd === 'git' && args[0] === 'rev-parse') return 'abc123\n';
      return r || '';
    },
    download: async (url, dest) => { calls.push(`download ${url}`); writeFileSync(dest, 'tgz'); },
    backup: async () => 'hermes-zalo-x.zip',
    restartSidecar: async () => calls.push('restart sidecar'),
    restartAssistant: async () => calls.push('restart assistant'),
    restartDashboard: async () => calls.push('restart dashboard'),
    healthy: async () => healthy(calls),
    sleep: async (ms) => { clock += ms; },
    now: () => clock,
  };
  const stateFile = join(root, 'state.json');
  const go = (to = 'v2.9.0') => runSelfUpdate({ root, hermesHome: '/h', to, from: '2.8.3', stateFile, tmpDir: tmp, deps });
  return { root, calls, logs, go, deps, state: () => JSON.parse(readFileSync(stateFile, 'utf8')) };
}

test('bản cài git: sao lưu → checkout tag → cài bằng bộ cài mã mới → khởi động lại 3 phần → khoẻ', async (t) => {
  const { calls, go, state } = setup(t);
  const st = await go();
  assert.equal(st.status, 'done');
  const seq = calls.filter((c) => !c.startsWith('git status')).map((c) => (c.includes('install-hermes.js') ? c.replace(/^node \S+install-hermes\.js/, 'install').replace(/--sidecar-root \S+/, '--sidecar-root ROOT') : c));
  assert.deepEqual(seq, [
    'git rev-parse HEAD', 'git fetch -q --tags origin', 'git checkout -q v2.9.0',
    'install --hermes-home /h --sidecar-root ROOT --no-dashboard',
    'restart sidecar', 'restart assistant', 'restart dashboard',
  ]);
  assert.ok(!calls.some((c) => c.startsWith('npm')), 'thư viện không đổi → không npm ci');
  assert.equal(state().status, 'done');
});

test('package-lock đổi thì chạy npm ci', async (t) => {
  const { calls, go } = setup(t, { lockChangesOn: 'git checkout -q v2.9.0' });
  assert.equal((await go()).status, 'done');
  assert.ok(calls.some((c) => c.startsWith('npm ci --omit=dev')));
});

test('không khoẻ sau khi cập nhật → quay về commit cũ, cài lại, khởi động lại', async (t) => {
  const { calls, go } = setup(t, { healthy: (c) => (c.includes('git checkout -q abc123') ? { ok: true } : { ok: false, detail: 'trợ lý chưa nối' }) });
  const st = await go();
  assert.equal(st.status, 'rolled-back');
  assert.match(st.error, /chưa chạy lại bình thường/);
  const back = calls.indexOf('git checkout -q abc123');
  assert.ok(back > calls.indexOf('git checkout -q v2.9.0'));
  assert.ok(calls.slice(back).some((c) => c.includes('install-hermes.js')));
  assert.equal(calls.slice(back).filter((c) => c.startsWith('restart')).length, 3);
});

test('quay về bản cũ: gỡ plugin ở <HERMES_HOME>/plugins TRƯỚC khi chạy bộ cài cũ (bản cũ chép vào mã Hermes)', async (t) => {
  const { calls, go, deps } = setup(t, { healthy: (c) => (c.includes('git checkout -q abc123') ? { ok: true } : { ok: false, detail: 'x' }) });
  deps.removeUserPlugins = async () => calls.push('remove user plugins');
  assert.equal((await go()).status, 'rolled-back');
  const removed = calls.indexOf('remove user plugins');
  assert.ok(removed > calls.indexOf('git checkout -q abc123'), 'sau khi lấy lại mã cũ');
  assert.ok(removed < calls.findLastIndex((c) => c.includes('install-hermes.js')), 'trước bộ cài cũ');
  assert.equal(calls.filter((c) => c === 'remove user plugins').length, 1, 'cập nhật thành công thì không gỡ');
});

test('mã nguồn có sửa đổi chưa commit → dừng trước khi đụng gì', async (t) => {
  const { calls, go } = setup(t, { runHook: (l) => (l.startsWith('git status') ? ' M server.js\n' : '') });
  const st = await go();
  assert.equal(st.status, 'failed');
  assert.match(st.error, /chưa commit/);
  assert.ok(!calls.some((c) => c.includes('checkout') || c.startsWith('restart')));
});

test('bản cài không git: nén mã cũ, tải gói phát hành, giải nén đè; lỗi cài → giải nén lại mã cũ', async (t) => {
  const { calls, go } = setup(t, { git: false, runHook: (l) => (l.includes('install-hermes.js') && !globalThis.__once ? (globalThis.__once = true, new Error('install lỗi')) : '') });
  t.after(() => { delete globalThis.__once; });
  const st = await go();
  assert.equal(st.status, 'rolled-back');
  assert.ok(calls.some((c) => /^tar -czf .*code-before-update\.tar\.gz --exclude=\.\/node_modules --exclude=\.\/data --exclude=\.\/\.env/.test(c)));
  assert.ok(calls.includes('download https://codeload.github.com/luonghaianh1208/2anh-zalo-bot/tar.gz/refs/tags/v2.9.0'));
  assert.ok(calls.some((c) => /^tar -xzf .*2anh-zalo-bot-v2\.9\.0\.tar\.gz .*--strip-components=1/.test(c)));
  assert.ok(calls.some((c) => /^tar -xzf .*code-before-update\.tar\.gz -C /.test(c)), 'quay về mã cũ');
});

test('phiên bản lạ bị từ chối', async (t) => {
  const { go } = setup(t);
  await assert.rejects(go('v2.9.0; rm -rf /'), /không hợp lệ/);
  await assert.rejects(go('main'), /không hợp lệ/);
});

test('dấu vân tay thư viện: đổi số phiên bản bot không tính là đổi thư viện', async (t) => {
  const { depsHash } = await import('./self-update-lib.js');
  const dir = mkdtempSync(join(tmpdir(), 'zalo-lock-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const lock = (v, zca) => JSON.stringify({ name: 'x', version: v, packages: { '': { version: v, dependencies: { 'zca-js': '^2.1.2' } }, 'node_modules/zca-js': { version: zca } } });
  const f = join(dir, 'package-lock.json');
  writeFileSync(f, lock('2.9.0', '2.1.2')); const a = depsHash(f);
  writeFileSync(f, lock('2.9.1', '2.1.2')); assert.equal(depsHash(f), a);
  writeFileSync(f, lock('2.9.1', '2.2.0')); assert.notEqual(depsHash(f), a);
});

test('bộ cài được tới 30 phút (Hermes mới chạy hermes pm install); chờ khoẻ chỉ bắt đầu sau khi bộ cài xong', async (t) => {
  const { calls, deps, go } = setup(t, { healthy: (c) => ({ ok: c.includes('restart dashboard') }) });
  const inner = deps.run;
  let installOpts = null;
  deps.run = async (cmd, args, opts) => {
    if (args.some((a) => String(a).endsWith('install-hermes.js'))) installOpts = opts;
    return inner(cmd, args, opts);
  };
  let healthAt = -1;
  const healthy = deps.healthy;
  deps.healthy = async () => { if (healthAt < 0) healthAt = calls.length; return healthy(); };
  assert.equal((await go()).status, 'done');
  assert.equal(installOpts.timeout, INSTALL_TIMEOUT_MS);
  assert.ok(INSTALL_TIMEOUT_MS >= 25 * 60_000);
  assert.ok(healthAt > calls.findIndex((c) => c.includes('install-hermes.js')));
});
